package mainpackage.passenger;

public class DummyObjectCreator {
    //Passenger p1 = new Passenger() idLength - 05
    //Passenger p2 = new Passenger()
    //oos.writeObject(p1)  ---> Passenger.bin
    //oos.writeObject(p2)

    /*
    Doctor d1 = new Doctor(); idLength - 04
    Doctor d2 = new Doctor();
    oss.writeObject (d1);  ---> Doctor.bin
    oos.writeObject (d2);
     */

}
