package mainpackage.passenger;

import java.io.Serializable;

public class Doctor implements Serializable {

    //fields
}
